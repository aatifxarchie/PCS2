import time
# importing the time module

def square():
    while True:
        file = open('memory.txt','r')
        # reading the shared memory file
        content = file.read()
        if content == '':
            sq = 0
        else:
            sq = int(content)
        # sqauring the counter obtained from shared memory file
        print(f'Square = {sq**2}')
        time.sleep(1)
        # setting a sleep time of 1 sec

square() # function call
