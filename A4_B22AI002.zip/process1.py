import time
# importing the time module


def counter():
    # initializing a counter
    count = 0
    while True:
        # reading the shared memory
        file = open('memory.txt', 'w')
        file.write(str(count))
        # writing the content in the shared memory
        time.sleep(5)
        # setting a sleep time of 5 sec
        print(f'Counter = {count}')
        count += 1

counter() # function call
